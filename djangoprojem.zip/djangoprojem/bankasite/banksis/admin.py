from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Musteri)
admin.site.register(Hesap)
admin.site.register(Transfer)
admin.site.register(Odeme)