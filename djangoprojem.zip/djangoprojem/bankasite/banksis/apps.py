from django.apps import AppConfig


class BanksisConfig(AppConfig):
    name = 'banksis'
